from conexionBD import *

class Operaciones:
    @staticmethod
    def insertar(numero1,numero2,signo,resultado):
        try:
            sql = "insert into operaciones values(null,NOW(),%s,%s,%s,%s)"
            val = (numero1,numero2,signo,resultado)
            cursor.execute(sql,val)
            conexion.commit()
            return True
        except:
            return False
    @staticmethod    
    def consultar():
        try:
            sql = "select * from operaciones"
            cursor.execute(sql)
            return cursor.fetchall()
        except:
            return False
    @staticmethod    
    def actualizar(fecha,numero1,numero2,signo,resultado,id):
        try:
            cursor.execute("update operaciones set fecha = %s, numero1 = %s, numero2 = %s, signo = %s, resultado = %s where id = %s",(fecha,numero1,numero2,signo,resultado,id))
            conexion.commit()
            return True
        except:
            return False
    @staticmethod    
    def eliminar(id):
        try:
            cursor.execute("delete from operaciones where id = %s",(id,))
            conexion.commit()
            return True
        except:
            return False
        
    @staticmethod
    def buscar(id,usuario_id):
        cursor.execute(f"select * from notas where id = {id} and usuario_id = {usuario_id}")
        registro = cursor.fetchall()
        if registro == []:
            return False
        else:
            return True