from tkinter import *
from tkinter import messagebox
from controller import funciones
from conexionBD import *
from tkinter import ttk
from model.operaciones import *

class Vista:
    def __init__(self,ventana):
        ventana.title("Calculadora")
        ventana.geometry("400x700")
        ventana.resizable(False,False)
        ventana.config(bg="#ffffff")
        self.valores = None
        self.interfaz_principal(ventana)

    @staticmethod
    def menuPrincipal(ventana):
        menuBar = Menu(ventana)
        ventana.config(menu=menuBar)    
        archivoMenu = Menu(menuBar , tearoff=0)
        menuBar.add_cascade(label="Archivo" , menu=archivoMenu)
        archivoMenu.add_command(label="Agregar",command=lambda: "" )
        archivoMenu.add_command(label="Consultar",command=lambda: "" )
        archivoMenu.add_command(label="Cambiar",command=lambda: "" )
        archivoMenu.add_command(label="Borrar",command=lambda: Vista.interfaz_eliminar(ventana) )
        archivoMenu.add_separator()
        archivoMenu.add_command(label="Salir",command=ventana.quit)

    @staticmethod
    def interfaz_eliminar(ventana):
        Vista.limpiar_ventana(ventana)
        lbl_titulo = Label(ventana,text=".::Borrar una operacion::.")
        lbl_titulo.pack()
        lbl_id = Label(ventana,text="ID de la Operación:")
        lbl_id.pack()
        id = IntVar()
        txt_id = Entry(ventana,textvariable=id) 
        txt_id.pack()
        btn_eliminar = Button(ventana,text="Eliminar",command=lambda:Vista.eliminar(txt_id.get()))
        btn_eliminar.pack()
        btn_volver = Button(ventana,text="Volver",command=lambda:Vista.interfaz_principal(ventana,ventana))
        btn_volver.pack()
    @staticmethod
    def limpiar_ventana(ventana):
        for widget in ventana.winfo_children():
            widget.pack_forget()

    @staticmethod
    def eliminar(id):
        eliminar = Operaciones.eliminar(id)
        if eliminar:
            messagebox.showinfo("Exito",f"Se eliminó el registro con ID:{id} exitosamente")
        else:
            messagebox.showinfo("Error",f"No fue posible eliminar el registro")
        

    def interfaz_principal(self,ventana):
        Vista.menuPrincipal(ventana)
        Vista.limpiar_ventana(ventana)
        Label(ventana,text="CALCULADORA",font=("Arial",20,"bold")).pack()
        frame_valores = Frame(ventana)
        frame_valores.pack(fill="x",padx=100)
        lbl_val1 = Label(frame_valores,text="Valor 1",font=("Arial",16))
        lbl_val1.grid(row=0,column=0)
        valor1 = IntVar()
        entry1 = Entry(frame_valores,width=10,textvariable=valor1)
        entry1.grid(row=0,column=1)

        lbl_val1 = Label(frame_valores,text="Valor 2",font=("Arial",16))
        lbl_val1.grid(row=1,column=0)
        valor2 = IntVar()
        entry2 = Entry(frame_valores,width=10,textvariable=valor2)
        entry2.grid(row=1,column=1)

        frame_botones = Frame(ventana)
        frame_botones.pack(fill="x",padx=70,pady=20)

        btn_suma = Button(frame_botones,text="+",font=("Arial",14),command=lambda:funciones.Funciones.operacion("Suma",valor1.get(),valor2.get(),"+"),width=10)
        btn_suma.grid(row=0,column=0,padx=5,pady=5)

        btn_resta = Button(frame_botones,text="-",font=("Arial",14),command=lambda:funciones.Funciones.operacion("Resta",valor1.get(),valor2.get(),"-"),width=10)
        btn_resta.grid(row=0,column=1,padx=5,pady=5)

        btn_multi = Button(frame_botones,text="x",font=("Arial",14),command=lambda:funciones.Funciones.operacion("Multiplicación",valor1.get(),valor2.get(),"*"),width=10)
        btn_multi.grid(row=1,column=0,padx=5,pady=5)

        btn_div = Button(frame_botones,text="/",font=("Arial",14),command=lambda:funciones.Funciones.operacion("División",valor1.get(),valor2.get(),"/"),width=10)
        btn_div.grid(row=1,column=1,padx=5,pady=5)
        Label(ventana,text="Historial").pack()
        consulta = Operaciones.consultar()
        columnas = ["ID","Fecha","Num 1", "Num 2","Signo","Resultado"]
        tamaños = [30,70,40,40,30,50]
        tabla = ttk.Treeview(ventana, columns=columnas, show="headings")
        i = 0
        for col in columnas:
            tabla.heading(col, text=col)
            tabla.column(col, anchor="center", width=tamaños[i])
            i+=1
        for fila in consulta:
            tabla.insert("", "end", values=fila)
        tabla.pack(fill="both", expand=True)
        def seleccionar_fila(event):
            fila = tabla.selection()  # Obtiene ID(s) de las filas seleccionadas
            if fila:
                self.valores = tabla.item(fila[0], "values")  # Obtiene los valores
        tabla.bind("<<TreeviewSelect>>", seleccionar_fila)
        """ btn_calcular = Button(ventana,text="=",font=("Arial",14),command="",width=10)
        btn_calcular.pack() """
        """ 
        btn_eliminar = Button(ventana,text="Eliminar",font=("Arial",14),command=lambda:funciones.Funciones.eliminar(self.valores[0]),width=10)
        btn_eliminar.pack(pady=10)
        """

        btn_salir = Button(ventana,text="Salir",font=("Arial",14),command=ventana.destroy,width=10)
        btn_salir.pack(pady=10)
